package com.DaySeven;

public class StaticDemoExecutor {
	public static void main(String[] args) {
		StaticDemo c1 = new StaticDemo();
		System.out.println(c1);
	}
}