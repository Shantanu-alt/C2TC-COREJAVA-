package com.DaySeven;

public class EmployeeExecutor {
	public static void main(String[] args) {
		Employee c1 = new Employee("Soham", 97);
		System.out.println(c1.toString());
	}
}
