package com.DayOne;

public class helloWorld {
	public static void main(String args[]) {
		System.out.println("Hii");
	}
}
class secondClass {
	public static void main(String[] args) {
		System.out.println("Hello");
	}
}

class thirdClass {
	public static void main(String[] args) {
		System.out.println("Namaste");
	}
}
