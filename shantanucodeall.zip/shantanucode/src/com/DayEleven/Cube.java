package com.DayEleven;

public interface Cube {
	int calculate(int a);
}
