package com.DayEleven;
@FunctionalInterface
public interface Message {
	void greet(String name);
}
