package com.DayFour;

/*
 * Flow control : Iterative statement
 * do-while loop
 * */
public class DoWhileLoop {

	@SuppressWarnings("unused")
	public static void main(String[] args) {
        int i = 0;
        do {
            System.out.println(i);
            i++;
        } while (i < 5);
	}

}