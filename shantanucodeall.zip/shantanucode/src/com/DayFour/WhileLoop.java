package com.DayFour;

public class WhileLoop {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		final int a = 10, b = 20;
		while (a < b)
			System.out.println("Hello Engineers");
//		System.out.println("Hi Kids");// Compile time error: Unreachable code

	}
}
