package com.DayEight;

public class CheckedException {
	public static void main(String[] args) throws InterruptedException {
		Thread.sleep(5000);
		System.out.println("I am in sleeping mode");
	}
}
